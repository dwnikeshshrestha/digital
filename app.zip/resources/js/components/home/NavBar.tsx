export default function NavBar() {
    return (
        <header className="">
            <nav className="nav-menu h-[122px]">
                
            </nav>
        </header>
    );
}
